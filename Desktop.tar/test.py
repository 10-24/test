from nonebot import on_regex
from nonebot.rule import to_me
from nonebot.typing import T_State
from nonebot.adapters import Bot, Event

gen = on_regex("梗", priority=5)


@gen.handle()
async def handle_first_receive(bot: Bot, event: Event, state: T_State):
    args = str(event.get_message()).strip()  # 首次发送命令时跟随的参数，例：/天气 上海，则args为上海
    if args:
        state["name"] = args  # 如果用户发送了参数则直接赋值


@gen.got("name", prompt="你想看什么梗呢？")
async def handle_gen(bot: Bot, event: Event, state: T_State):
    name = state["name"]
    if name not in ["daisuke", "brain power"]:
        await weather.reject("您的梗还没有录入，请重新输入！")
    gen_ing = await get_gen(name)
    await gen.finish(gen_ing)


async def get_gen(name: str):
    if name == "daisuke"
        return f"{name}的dai是..."